<?php
 
$servername = "sql103.infinityfree.com";
$username = "if0_37680929";
$password = "Mbq134234567890";
$dbname = "if0_37680929_ukmcampush";
 
?>