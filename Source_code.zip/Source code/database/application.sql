-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2024-12-18 16:39:02
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `mylocal`
--

-- --------------------------------------------------------

--
-- 表的结构 `application`
--

CREATE TABLE `application` (
  `applyid` int(255) NOT NULL,
  `employerid` int(255) NOT NULL,
  `studentid` int(255) NOT NULL,
  `jobid` int(255) NOT NULL,
  `student` varchar(255) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_matric` varchar(255) NOT NULL,
  `student_faculty` varchar(255) NOT NULL,
  `employer` varchar(255) NOT NULL,
  `employer_email` varchar(255) NOT NULL,
  `shop` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `jobtitle` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `application`
--

INSERT INTO `application` (`applyid`, `employerid`, `studentid`, `jobid`, `student`, `student_email`, `student_matric`, `student_faculty`, `employer`, `employer_email`, `shop`, `position`, `status`, `jobtitle`) VALUES
(24, 1, 2, 67, 'Myra', 'aasd@aasd1.com', 'A33453', 'FTSM', 'Ali', 'a1123@gmail.com', 'hot meal bah', 'pusanika', 'Validated', 'salesperson'),
(25, 2, 3, 5, 'Jacky', 'aasd@aa2sd.com', 'A133425', 'FKAB', 'Bob', 'a191309@siswa.ukm.edu.my', 'Switch Campus', 'UKM Bangi', 'Accepted', 'Cashier'),
(26, 1, 4, 62, 'Adam', 'aa223sd@aasd.com', 'A211453', 'GSB', 'Ali', 'a1123@gmail.com', 'hot meal bah', 'pusanika', 'Accepted', 'Chef'),
(27, 1, 5, 66, 'San', 'a192234@siswa.ukm.edu.my', 'A192234', 'FTSM', 'Ali', 'a1123@gmail.com', 'hot meal bah', 'pusanika', 'AdminDenied', 'salesperson'),
(28, 1, 9, 63, 'Cong', 'cctv13@gmail.com', 'A113342', 'GSB', 'Ali', 'a1123@gmail.com', '99speed', 'pusanika', 'Accepted', 'Salsesperson'),
(29, 1, 10, 63, 'Wen', 'cctv14@gmail.com', 'A112366', 'FPERG', 'Ali', 'a1123@gmail.com', '99speed', 'pusanika', 'Accepted', 'Salsesperson'),
(33, 1, 12, 62, 'Frank', 'fa16@gmail.com', 'A167780', 'FTSM', 'Ali', 'a1123@gmail.com', 'hot meal bah', 'pusanika', 'Accepted', 'Chef'),
(34, 1, 11, 1, 'David', 'david15@gmail.com', 'A128899', 'FTSM', 'Ali', 'a1123@gmail.com', 'hot meal bah', 'pusanika', 'Accepted', 'Cashier'),
(39, 2, 1, 2, 'MA BO QI', 'aasd@aasd.com', 'A12222', 'FTSM', 'Bob', 'a191309@siswa.ukm.edu.my', 'Esport', 'UKM Pusanika', 'Applied', 'Salesperson');

--
-- 转储表的索引
--

--
-- 表的索引 `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`applyid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `application`
--
ALTER TABLE `application`
  MODIFY `applyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
