-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2024-12-18 16:39:11
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `mylocal`
--

-- --------------------------------------------------------

--
-- 表的结构 `employer`
--

CREATE TABLE `employer` (
  `userid` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `usertype` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `shop` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `employer`
--

INSERT INTO `employer` (`userid`, `firstname`, `lastname`, `email`, `usertype`, `phone`, `shop`, `pwd`) VALUES
(1, 'Ali', 'Liu', 'a1123@gmail.com', 'employer', '1223455', 'Hot meal bah', '112'),
(2, 'Bob', 'eee', 'a191309@siswa.ukm.edu.my', 'employer', '0148874609', 'Esport', '112'),
(6, 'Lee', 'Jack', '151633@gmail.com', 'employer', '01156889', 'Cafe', '002');

--
-- 转储表的索引
--

--
-- 表的索引 `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `employer`
--
ALTER TABLE `employer`
  MODIFY `userid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
